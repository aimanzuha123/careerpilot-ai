# dashboard/app.py
"""
CareerPilot AI -- Phase 2 Streamlit Dashboard

New in Phase 2:
  - Resume PDF upload + text paste fallback
  - Skill match score + gap analysis panel
  - Role switching with metadata cards
  - Gap-driven learning plan view
  - Side-by-side: resume skills vs market gaps
"""

import sys
import os
import json
from typing import Optional

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import streamlit as st
from pipelines.core_pipeline import CorePipeline
from pipelines.role_manager import RoleManager, ROLE_METADATA

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CareerPilot AI",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Sora:wght@300;400;500;600;700&display=swap');

:root {
  --bg:       #080c18; --bg1: #0f1726; --bg2: #151f33; --bg3: #1c2840;
  --border:   #1e2d45; --border-hi: #2a3f60;
  --text:     #dde4f0; --muted: #6b7a96;
  --green:    #00e5a0; --green-dim: #00a370;
  --blue:     #4da6ff; --yellow: #ffc947; --red: #ff5c7a; --purple: #b87fff;
}
.stApp { background:var(--bg); color:var(--text); font-family:'Sora',sans-serif; }
[data-testid="stSidebar"] { background:#0a1020!important; border-right:1px solid var(--border); }
.stButton>button {
  background:linear-gradient(135deg,var(--green),var(--green-dim))!important;
  color:#060a12!important; border:none!important;
  font-family:'IBM Plex Mono',monospace!important; font-weight:600!important;
  border-radius:8px!important; letter-spacing:.04em!important; padding:10px 20px!important;
}
[data-testid="stTabContent"] { background:transparent!important; }
div[role="tab"] { font-family:'IBM Plex Mono',monospace!important; font-size:.82rem!important; color:var(--muted)!important; }
div[role="tab"][aria-selected="true"] { color:var(--green)!important; border-bottom:2px solid var(--green)!important; }
.stSelectbox label,.stSlider label,.stRadio label,.stFileUploader label,.stTextArea label { color:var(--muted)!important; font-size:.8rem!important; }
h1,h2,h3 { font-family:'IBM Plex Mono',monospace!important; }
hr { border-color:var(--border)!important; }

.card { background:var(--bg1); border:1px solid var(--border); border-radius:12px; padding:20px 24px; margin-bottom:14px; transition:border-color .2s; }
.card:hover { border-color:var(--border-hi); }
.hero { background:linear-gradient(120deg,#0f1726 0%,#141e34 60%,#0d1828 100%);
  border:1px solid var(--border); border-top:3px solid var(--green); border-radius:14px;
  padding:28px 32px; margin-bottom:22px; position:relative; overflow:hidden; }
.hero::after { content:''; position:absolute; top:-80px; right:-80px; width:260px; height:260px;
  background:radial-gradient(circle,rgba(0,229,160,.07) 0%,transparent 70%); pointer-events:none; }
.hero-title { font-family:'IBM Plex Mono',monospace; font-size:1.9rem; color:var(--green); font-weight:600; margin:0 0 6px; }
.hero-sub { color:var(--muted); font-size:.9rem; }
.hero-badges { margin-top:12px; display:flex; gap:8px; flex-wrap:wrap; }
.badge { background:rgba(0,229,160,.09); border:1px solid rgba(0,229,160,.25); color:var(--green);
  padding:3px 10px; border-radius:20px; font-size:.72rem; font-family:'IBM Plex Mono',monospace; }
.badge-blue { background:rgba(77,166,255,.09); border-color:rgba(77,166,255,.25); color:var(--blue); }
.badge-yellow { background:rgba(255,201,71,.09); border-color:rgba(255,201,71,.25); color:var(--yellow); }

.sk-row { display:flex; align-items:center; padding:8px 0; border-bottom:1px solid rgba(255,255,255,.04); }
.sk-row:last-child { border:none; }
.sk-rank { font-family:'IBM Plex Mono',monospace; font-size:.68rem; color:var(--muted); width:26px; flex-shrink:0; }
.sk-name { font-size:.86rem; color:var(--text); width:155px; flex-shrink:0; font-weight:500; }
.sk-bar  { flex:1; background:rgba(255,255,255,.06); border-radius:4px; height:7px; margin:0 12px; overflow:hidden; }
.sk-fill { height:100%; border-radius:4px; }
.sk-freq { font-family:'IBM Plex Mono',monospace; font-size:.68rem; color:var(--muted); width:50px; text-align:right; }

.gap-row { display:flex; align-items:center; padding:9px 0; border-bottom:1px solid rgba(255,255,255,.04); }
.gap-row:last-child { border:none; }
.gap-idx { font-family:'IBM Plex Mono',monospace; width:26px; font-size:.68rem; color:var(--muted); flex-shrink:0; }
.gap-name { flex:1; font-size:.88rem; color:var(--text); font-weight:500; }
.gap-cat  { font-size:.72rem; color:var(--muted); width:140px; }
.gap-fr   { font-family:'IBM Plex Mono',monospace; font-size:.7rem; color:var(--muted); width:48px; text-align:right; }

.chip-match { display:inline-block; background:rgba(0,229,160,.1); border:1px solid rgba(0,229,160,.25);
  color:var(--green); padding:3px 10px; border-radius:14px; font-size:.78rem; font-family:'IBM Plex Mono',monospace; margin:3px; }
.chip-gap { display:inline-block; background:rgba(255,92,122,.1); border:1px solid rgba(255,92,122,.25);
  color:var(--red); padding:3px 10px; border-radius:14px; font-size:.78rem; font-family:'IBM Plex Mono',monospace; margin:3px; }

.wk-card { background:var(--bg1); border:1px solid var(--border); border-radius:12px; padding:20px 24px; margin-bottom:14px; }
.wk-card:hover { border-color:var(--border-hi); }
.wk-hdr  { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:14px; }
.wk-num  { font-family:'IBM Plex Mono',monospace; color:var(--green); font-size:.78rem; }
.wk-theme { font-size:.96rem; font-weight:600; color:var(--text); margin-top:2px; }
.wk-date  { font-size:.75rem; color:var(--muted); margin-top:2px; }
.wk-hrs   { background:rgba(0,229,160,.1); border:1px solid rgba(0,229,160,.2); color:var(--green);
  padding:3px 10px; border-radius:20px; font-family:'IBM Plex Mono',monospace; font-size:.72rem; white-space:nowrap; }
.tk-row   { display:flex; align-items:center; padding:8px 0; border-bottom:1px solid rgba(255,255,255,.04); font-size:.86rem; }
.tk-row:last-child { border:none; }
.tk-hrs   { background:rgba(77,166,255,.1); border:1px solid rgba(77,166,255,.2); color:var(--blue);
  font-family:'IBM Plex Mono',monospace; font-size:.68rem; padding:2px 7px; border-radius:4px;
  margin-right:10px; flex-shrink:0; min-width:34px; text-align:center; }
.tk-name  { flex:1; color:var(--text); font-weight:500; }
.tk-gap   { background:rgba(255,92,122,.1); border:1px solid rgba(255,92,122,.2); color:var(--red);
  font-size:.65rem; font-family:'IBM Plex Mono',monospace; padding:1px 6px; border-radius:4px; margin-right:8px; flex-shrink:0; }
.tk-plat  { color:var(--muted); font-size:.76rem; text-align:right; }
.info-box { background:rgba(77,166,255,.06); border:1px solid rgba(77,166,255,.2); border-radius:8px;
  padding:12px 16px; font-size:.84rem; color:var(--blue); }
.score-val   { font-family:'IBM Plex Mono',monospace; font-size:2.8rem; font-weight:600; line-height:1; }
.score-label { font-size:.72rem; color:var(--muted); text-transform:uppercase; letter-spacing:.08em; margin-top:4px; }
</style>
""", unsafe_allow_html=True)


# ── Helpers ───────────────────────────────────────────────────────────────────
@st.cache_data(ttl=120, show_spinner=False)
def run_pipeline_cached(role, level, hours, resume_bytes, resume_filename, resume_text):
    p = CorePipeline(role_type=role, skill_level=level, hours_per_week=hours, top_n_skills=20)
    return p.run(resume_bytes=resume_bytes, resume_filename=resume_filename, resume_text=resume_text)

def score_color(s):
    return ("var(--green)" if s >= 70 else "var(--yellow)" if s >= 40 else "var(--red)")

def demand_color(d):
    return {"HIGH": "var(--red)", "MEDIUM": "var(--yellow)", "LOW": "var(--green)"}.get(d, "var(--muted)")

def demand_icon(d):
    return {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(d, "⚪")

def skill_bar(rank, skill, freq, max_freq, color="var(--green)"):
    pct = int((freq / max_freq) * 100) if max_freq else 0
    st.markdown(f"""<div class="sk-row">
      <span class="sk-rank">#{rank:02d}</span>
      <span class="sk-name">{skill.title()}</span>
      <div class="sk-bar"><div class="sk-fill" style="width:{pct}%;background:{color};"></div></div>
      <span class="sk-freq">{freq}x jobs</span></div>""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""<div style="text-align:center;padding:14px 0 22px;">
      <div style="font-family:'IBM Plex Mono',monospace;font-size:1.25rem;color:#00e5a0;font-weight:600;">🎯 CareerPilot AI</div>
      <div style="font-size:.7rem;color:#6b7a96;margin-top:3px;">Phase 2 — Personalization</div>
    </div>""", unsafe_allow_html=True)

    st.markdown("### Settings")
    rm_inst = RoleManager()
    role_type = st.selectbox("Target Role", rm_inst.VALID_ROLES, index=0)
    meta = ROLE_METADATA[role_type]
    st.caption(f"{meta['icon']} {meta['label']} · {meta['hiring_trend']}")
    skill_level = st.radio("Skill Level", ["Beginner", "Intermediate", "Advanced"], index=1)
    hours_per_week = st.slider("Hours / Week", 3.0, 25.0, 10.0, 0.5)

    st.markdown("---")
    st.markdown("### Resume")
    resume_mode = st.radio("Input Mode", ["Upload PDF", "Paste Text", "No Resume"], index=2)

    resume_bytes: Optional[bytes] = None
    resume_filename = "resume.pdf"
    resume_text_input: Optional[str] = None

    if resume_mode == "Upload PDF":
        uploaded = st.file_uploader("", type=["pdf"], label_visibility="collapsed")
        if uploaded:
            resume_bytes = uploaded.read()
            resume_filename = uploaded.name
            st.success(f"Loaded: {uploaded.name}")
    elif resume_mode == "Paste Text":
        resume_text_input = st.text_area(
            "", height=160, label_visibility="collapsed",
            placeholder="Paste skills or resume text...\n\nExample:\nPython, Docker, FastAPI, PostgreSQL\nBuilt ML models with TensorFlow on AWS..."
        )

    st.markdown("---")
    run_btn = st.button("Analyze & Generate Plan", use_container_width=True)

    st.markdown("""<div style="font-size:.7rem;color:#4a5568;margin-top:12px;line-height:1.8;">
      <b style="color:#4da6ff;">Phase 2</b><br>
      ✓ PDF resume parser<br>
      ✓ Skill match scoring<br>
      ✓ Gap priority ranking<br>
      ✓ Role metadata cards<br>
      ✓ Gap-driven weekly plan<br>
      <br><b style="color:#ffc947;">Phase 3 Next</b><br>
      ○ Trend charts<br>○ FastAPI endpoints
    </div>""", unsafe_allow_html=True)


# ── Pipeline execution ────────────────────────────────────────────────────────
effective_text = resume_text_input if resume_mode == "Paste Text" else None

if "result" not in st.session_state or run_btn:
    with st.spinner("Analyzing job market & resume..."):
        try:
            result = run_pipeline_cached(
                role_type, skill_level.lower(), hours_per_week,
                resume_bytes, resume_filename, effective_text
            )
            st.session_state["result"] = result
        except Exception as e:
            st.error(f"Pipeline error: {e}")
            st.stop()

result = st.session_state.get("result", {})
if not result:
    st.info("Configure your settings and click Analyze & Generate Plan.")
    st.stop()

has_resume = result.get("has_resume", False)
plan       = result.get("plan", {})
ra         = result.get("resume_analysis")
role_ctx   = result.get("role_context", {})
data_stats = result.get("data_stats", {})
top_skills = result.get("top_skills", [])

# ── Hero ──────────────────────────────────────────────────────────────────────
resume_badge = '<span class="badge badge-blue">📄 Resume Analyzed</span>' if has_resume else ""
plan_badge   = f'<span class="badge badge-yellow">{"🎯 Gap Plan" if plan.get("gap_driven") else "📋 Market Plan"}</span>'
st.markdown(f"""<div class="hero">
  <div class="hero-title">🎯 CareerPilot AI</div>
  <div class="hero-sub">Agentic Job Market Intelligence &amp; Adaptive Career Planning</div>
  <div class="hero-badges">
    <span class="badge">◉ {role_type}</span><span class="badge">{skill_level}</span>
    {resume_badge}{plan_badge}
  </div></div>""", unsafe_allow_html=True)

# ── Metrics ───────────────────────────────────────────────────────────────────
c1,c2,c3,c4,c5 = st.columns(5)
with c1: st.metric("Jobs Analyzed", data_stats.get("total_jobs",0))
with c2: st.metric("Market Skills", result.get("skill_summary",{}).get("total_unique_skills",0))
with c3: st.metric("Resume Skills", ra["total_resume_skills"] if ra else "—")
with c4: st.metric("Match Score",   f"{ra['match_score']:.0f}%" if ra else "—")
with c5: st.metric("Skill Gaps",    len(ra["gap_skills"]) if ra else "—")
st.markdown("---")

# ── Tabs ──────────────────────────────────────────────────────────────────────
t1, t2, t3, t4 = st.tabs(["🎭 Role Info", "📊 Market Skills", "📄 Resume Analysis", "📅 Learning Plan"])


# ══════ TAB 1: ROLE INFO ═════════════════════════════════════════════════════
with t1:
    st.markdown("### Role Intelligence")
    c_l, c_r = st.columns([1.4, 1])
    act = ROLE_METADATA[role_type]

    with c_l:
        st.markdown(f"""<div class="card" style="border-color:{act['color']}44;">
          <div style="font-size:1.6rem;">{act['icon']}</div>
          <div style="font-family:'IBM Plex Mono',monospace;font-size:1.1rem;color:{act['color']};margin:6px 0 4px;">{act['label']}</div>
          <div style="font-size:.86rem;color:var(--muted);line-height:1.6;">{act['description']}</div>
          <div style="margin-top:12px;font-size:.82rem;">
            <span style="color:var(--muted);">Avg Salary: </span><b style="color:{act['color']};">${act['avg_salary_usd']:,}</b>
            &nbsp;&nbsp;<span style="color:var(--muted);">Trend: </span><b>{act['hiring_trend']}</b>
          </div></div>""", unsafe_allow_html=True)

        path = act.get("seniority_path", [])
        path_html = " → ".join(
            f'<b style="color:{act["color"]};">{p}</b>' if i == 1 else f'<span style="color:var(--muted);">{p}</span>'
            for i, p in enumerate(path)
        )
        st.markdown(f"**Career Path**")
        st.markdown(f'<div style="font-size:.82rem;line-height:2.2;">{path_html}</div>', unsafe_allow_html=True)

        tools_html = "".join(f'<span class="badge">{t}</span>' for t in act.get("daily_tools",[]))
        st.markdown("**Daily Tools**")
        st.markdown(f'<div style="margin-top:4px;">{tools_html}</div>', unsafe_allow_html=True)

    with c_r:
        st.markdown("**Key Companies Hiring**")
        for co in act.get("key_companies",[]):
            st.markdown(f'<div style="padding:7px 0;border-bottom:1px solid var(--border);font-size:.86rem;">🏢 {co}</div>',
                        unsafe_allow_html=True)
        st.markdown("**Certifications**")
        for cert in act.get("certifications",[]):
            st.markdown(f'<div style="padding:7px 0;border-bottom:1px solid var(--border);font-size:.83rem;color:var(--muted);">📜 {cert}</div>',
                        unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("#### Compare All Roles")
    rc = st.columns(4)
    for i, (rtype, rmeta) in enumerate(ROLE_METADATA.items()):
        with rc[i]:
            active_border = f"border:2px solid {rmeta['color']};" if rtype == role_type else ""
            st.markdown(f"""<div class="card" style="{active_border}text-align:center;">
              <div style="font-size:1.4rem;">{rmeta['icon']}</div>
              <div style="font-family:'IBM Plex Mono',monospace;font-size:.8rem;color:{rmeta['color']};margin-top:6px;">{rtype}</div>
              <div style="font-size:.75rem;color:var(--muted);margin-top:4px;">{rmeta['hiring_trend']}</div>
              <div style="font-size:.82rem;font-weight:600;margin-top:6px;">${rmeta['avg_salary_usd']//1000}k</div>
            </div>""", unsafe_allow_html=True)

    role_plan = role_ctx.get("plan_config", {})
    if role_plan:
        st.markdown("---")
        st.markdown("#### Weekly Focus Guide")
        for wk in range(1, 5):
            focus = role_plan.get(f"week{wk}_focus", "")
            st.markdown(
                f'<div style="display:flex;gap:12px;padding:9px 0;border-bottom:1px solid var(--border);font-size:.85rem;">'
                f'<span style="font-family:\'IBM Plex Mono\',monospace;color:{act["color"]};flex-shrink:0;width:28px;">W{wk}</span>'
                f'<span>{focus}</span></div>', unsafe_allow_html=True)

        proj = role_plan.get("project_ideas", [])
        if proj:
            st.markdown("#### Project Ideas")
            for idea in proj:
                st.markdown(f'<div style="padding:8px 0;border-bottom:1px solid var(--border);font-size:.85rem;">→ {idea}</div>',
                            unsafe_allow_html=True)


# ══════ TAB 2: MARKET SKILLS ═════════════════════════════════════════════════
with t2:
    st.markdown("### Job Market Skill Trends")
    st.caption(f"Role filter: **{role_type}** · {data_stats.get('total_jobs',0)} jobs analyzed")

    if top_skills:
        max_f = max(s["frequency"] for s in top_skills)
        col_l, col_r = st.columns(2)
        with col_l:
            st.markdown("#### Top 10")
            for i, sk in enumerate(top_skills[:10], 1):
                skill_bar(i, sk["skill"], sk["frequency"], max_f, "var(--green)")
        with col_r:
            st.markdown("#### Ranks 11–20")
            for i, sk in enumerate(top_skills[10:20], 11):
                skill_bar(i, sk["skill"], sk["frequency"], max_f, "var(--blue)")

    st.markdown("---")
    st.markdown("### By Category")
    cats = result.get("skills_by_category", {})
    if cats:
        cc = st.columns(3)
        for idx, (cat, skills) in enumerate(cats.items()):
            with cc[idx % 3]:
                with st.expander(f"📂 {cat.replace('_',' ').title()} ({len(skills)})"):
                    for sk, fr in skills[:10]:
                        st.markdown(
                            f'<div style="display:flex;justify-content:space-between;padding:5px 0;'
                            f'border-bottom:1px solid var(--border);font-size:.82rem;">'
                            f'<span>{sk.title()}</span>'
                            f'<span style="font-family:\'IBM Plex Mono\',monospace;color:var(--muted);">{fr}x</span></div>',
                            unsafe_allow_html=True)


# ══════ TAB 3: RESUME ANALYSIS ═══════════════════════════════════════════════
with t3:
    if not has_resume:
        st.markdown("""<div class="info-box" style="margin:20px 0;">
          Upload a PDF resume or paste text in the sidebar to unlock personalized analysis.
          Without a resume, you get a market-driven plan based on job trends.
        </div>""", unsafe_allow_html=True)
        feats = [
            ("📊", "Skill Match Score", "See what % of market skills you already have"),
            ("✅", "Matched Skills", "Skills you have that employers want"),
            ("❌", "Skill Gaps", "High-demand skills missing from your profile"),
            ("🎯", "Gap-Driven Plan", "4-week plan targeting YOUR specific gaps"),
        ]
        fc = st.columns(2)
        for i, (icon, title, desc) in enumerate(feats):
            with fc[i % 2]:
                st.markdown(f"""<div class="card">
                  <div style="font-size:1.4rem;">{icon}</div>
                  <div style="font-weight:600;margin:6px 0 4px;">{title}</div>
                  <div style="font-size:.82rem;color:var(--muted);">{desc}</div>
                </div>""", unsafe_allow_html=True)
    else:
        if not ra:
            st.error("Resume analysis unavailable.")
        else:
            s_color = score_color(ra["match_score"])
            c_color = score_color(ra["coverage_score"])

            st.markdown("### Resume Analysis Results")
            st.caption(f"File: `{ra['resume_source']}` · Analyzed: {ra['analyzed_at'][:10]}")

            mc1, mc2, mc3, mc4 = st.columns(4)
            for col, val, label, color in [
                (mc1, f"{ra['match_score']:.0f}%",  "Match Score",    s_color),
                (mc2, f"{ra['coverage_score']:.0f}%","Coverage",       c_color),
                (mc3, str(ra["total_resume_skills"]), "Resume Skills",  "var(--green)"),
                (mc4, str(len(ra["gap_skills"])),     "Skill Gaps",     "var(--red)"),
            ]:
                with col:
                    st.markdown(f"""<div class="card" style="text-align:center;">
                      <div class="score-val" style="color:{color};">{val}</div>
                      <div class="score-label">{label}</div>
                    </div>""", unsafe_allow_html=True)

            bar_pct = int(ra["match_score"])
            st.markdown(f"""<div style="margin:12px 0 22px;">
              <div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--muted);margin-bottom:5px;">
                <span>Match Score</span><span>{ra['match_score']:.1f}%</span></div>
              <div style="background:rgba(255,255,255,.07);border-radius:8px;height:12px;overflow:hidden;">
                <div style="width:{bar_pct}%;height:100%;border-radius:8px;
                     background:linear-gradient(90deg,{s_color},{s_color}88);"></div>
              </div></div>""", unsafe_allow_html=True)

            col_m, col_g = st.columns(2)

            with col_m:
                st.markdown(f"#### Matched Skills ({len(ra['matched_skills'])})")
                st.caption("You already have these — great!")
                if ra["matched_skills"]:
                    chips = "".join(f'<span class="chip-match">{s.title()}</span>' for s in ra["matched_skills"])
                    st.markdown(f'<div style="margin-top:8px;">{chips}</div>', unsafe_allow_html=True)
                else:
                    st.markdown('<div style="color:var(--muted);font-size:.85rem;">No matches found in market top skills.</div>',
                                unsafe_allow_html=True)
                if ra.get("resume_skills"):
                    with st.expander(f"All {ra['total_resume_skills']} detected resume skills"):
                        for sk in ra["resume_skills"]:
                            st.markdown(f"· {sk.title()}")

            with col_g:
                st.markdown(f"#### Skill Gaps ({len(ra['gap_skills'])})")
                st.caption("High-demand skills missing from your resume — prioritized by market demand")
                for i, gap in enumerate(ra["gap_skills"][:15], 1):
                    dc = demand_color(gap["demand_level"])
                    di = demand_icon(gap["demand_level"])
                    st.markdown(f"""<div class="gap-row">
                      <span class="gap-idx">#{i:02d}</span>
                      <span class="gap-name">{gap['skill'].title()}</span>
                      <span class="gap-cat">{gap['category'].replace('_',' ')}</span>
                      <span style="color:{dc};font-size:.72rem;font-family:'IBM Plex Mono',monospace;width:70px;text-align:center;">
                        {di} {gap['demand_level']}</span>
                      <span class="gap-fr">{gap['frequency']}x</span>
                    </div>""", unsafe_allow_html=True)

            # Interpretation
            score = ra["match_score"]
            msg, border_c = (
                ("🟢 Strong match! You already have many in-demand skills. Close the remaining gaps to reach the top tier.", "var(--green)") if score >= 70 else
                ("🟡 Good foundation. Meaningful gaps exist — your personalized plan targets them week by week.", "var(--yellow)") if score >= 40 else
                ("🔴 Large skill gap detected. Your plan prioritizes the highest-impact skills first to get you job-ready fast.", "var(--red)")
            )
            st.markdown(f"""<div style="margin-top:16px;background:rgba(255,255,255,.04);
                border:1px solid {border_c}44;border-left:4px solid {border_c};
                border-radius:8px;padding:14px 18px;font-size:.88rem;line-height:1.6;">
              {msg}</div>""", unsafe_allow_html=True)


# ══════ TAB 4: LEARNING PLAN ═════════════════════════════════════════════════
with t4:
    mode_label = "🎯 Gap-Driven" if plan.get("gap_driven") else "📋 Market-Driven"
    st.markdown(f"### 4-Week Learning Plan")
    st.caption(f"Mode: {mode_label} · Role: {role_type} · Level: {skill_level} · {hours_per_week:.0f}h/week · Total: {plan.get('total_hours',0):.0f}h")

    if plan.get("gap_driven"):
        st.markdown("""<div class="info-box" style="margin-bottom:18px;">
          🎯 This plan is personalized to YOUR resume. Gap tasks (marked <b style="color:var(--red);">GAP</b>) 
          address your specific missing skills. Skills you already have are excluded.
        </div>""", unsafe_allow_html=True)

    pc = {"HIGH": "var(--red)", "MEDIUM": "var(--yellow)", "LOW": "var(--green)"}

    for week in plan.get("weeks", []):
        wn = week["week_number"]
        gap_count = sum(1 for t in week["tasks"] if t.get("is_gap"))
        gap_tag = f'<span style="font-size:.7rem;color:var(--red);margin-left:8px;">({gap_count} gap tasks)</span>' if gap_count else ""

        st.markdown(f"""<div class="wk-card">
          <div class="wk-hdr">
            <div>
              <div class="wk-num">WEEK {wn}{gap_tag}</div>
              <div class="wk-theme">{week['theme']}</div>
              <div class="wk-date">Starts {week['start_date']}</div>
            </div>
            <div class="wk-hrs">{week['total_hours']}h</div>
          </div>""", unsafe_allow_html=True)

        for task in week["tasks"]:
            pr = task.get("priority", "MEDIUM")
            p_color = pc.get(pr, "var(--muted)")
            gap_badge = '<span class="tk-gap">GAP</span>' if task.get("is_gap") else ""
            name = task["skill"].title() if "Practice" not in task["skill"] else task["skill"]
            st.markdown(f"""<div class="tk-row">
              <div class="tk-hrs">{task['hours']}h</div>
              {gap_badge}
              <div class="tk-name">{name}</div>
              <div style="font-size:.72rem;color:{p_color};width:65px;text-align:center;font-family:'IBM Plex Mono',monospace;">{pr}</div>
              <div class="tk-plat">{task['platform']}</div>
            </div>""", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    ec1, ec2, ec3 = st.columns([1, 1, 1])
    with ec1:
        st.download_button("Export Plan (JSON)", json.dumps(plan, indent=2),
                           f"careerpilot_{role_type.lower()}_plan.json", "application/json",
                           use_container_width=True)
    with ec2:
        lines = [f"CareerPilot AI -- {role_type} Plan ({skill_level})", "="*50]
        if ra:
            lines += [f"Match Score: {ra['match_score']:.1f}%  Gaps: {len(ra['gap_skills'])}", "="*50]
        for w in plan.get("weeks", []):
            lines.append(f"\nWEEK {w['week_number']}: {w['theme']}")
            lines.append(f"Start: {w['start_date']} | {w['total_hours']}h")
            for t in w["tasks"]:
                tag = " [GAP]" if t.get("is_gap") else ""
                lines.append(f"  [{t['hours']}h] {t['skill'].title()}{tag} -- {t['platform']}")
        st.download_button("Export Plan (TXT)", "\n".join(lines),
                           f"careerpilot_{role_type.lower()}_plan.txt", "text/plain",
                           use_container_width=True)
    with ec3:
        if ra:
            full = {"config": result["config"], "resume_analysis": ra, "plan": plan}
            st.download_button("Export Full Analysis (JSON)", json.dumps(full, indent=2),
                               "careerpilot_full_analysis.json", "application/json",
                               use_container_width=True)

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("""<div style="text-align:center;padding:10px 0;font-size:.72rem;color:#2a3f60;font-family:'IBM Plex Mono',monospace;">
  CareerPilot AI · Phase 2 Personalization · Python + Streamlit + pdfplumber<br>
  Phase 3 → Trend Charts + FastAPI · Phase 4 → Agentic AI Agents
</div>""", unsafe_allow_html=True)
